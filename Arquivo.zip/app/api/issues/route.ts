// app/api/issues/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';
import { Issue } from '@/models/Issue';
import { getServerAuthSession } from '@/lib/auth';
import { parseSearchQuery } from '@/lib/searchParser'; // <-- Importação

export async function GET(req: NextRequest) {
  const session = await getServerAuthSession();
  if (!session?.user?.tenantId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  await connectToDatabase();
  const tenantId = session.user.tenantId;
  const { searchParams } = new URL(req.url);

  const id = searchParams.get('id');
  if (id) {
    const issue = await Issue.findOne({ _id: id, tenantId: session.user.tenantId }).lean();
    if (!issue) {
      return NextResponse.json({ error: 'Issue not found' }, { status: 404 });
    }
    return NextResponse.json(issue);
  }

  const status = searchParams.get('status');
  const category = searchParams.get('category');
  const severity = searchParams.get('severity');
  const assignedTo = searchParams.get('assignedTo');
  const search = searchParams.get('search');
  const branch = searchParams.get('branch');
  const repository = searchParams.get('repository');
  const projectId = searchParams.get('projectId');
  const all = searchParams.get('all') === 'true';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  let filter: any = { tenantId };

  if (status && status !== 'overdue') filter.status = status;
  if (status === 'overdue') {
    filter.status = { $in: ['open', 'recurring'] };
    filter.slaDueAt = { $lt: new Date() };
  }
  if (category) filter.category = category;
  if (severity) filter.severity = severity;
  if (assignedTo && assignedTo !== 'unassigned') filter.assignedTo = assignedTo;
  if (assignedTo === 'unassigned') filter.assignedTo = { $in: [null, ''] };
  if (branch) filter.branch = branch;
  if (repository) filter.repository = repository;
  if (projectId && projectId !== 'all') filter.project = projectId;

  if (search) {
    filter = parseSearchQuery(search, filter); // <-- Chamada à lib
  }

  const totalCount = await Issue.countDocuments(filter);
  let issues;
  if (all) {
    issues = await Issue.find(filter).sort({ firstSeen: -1 }).lean();
  } else {
    const skip = (page - 1) * limit;
    issues = await Issue.find(filter)
      .sort({ firstSeen: -1 })
      .skip(skip)
      .limit(limit)
      .lean();
  }

  return NextResponse.json({
    issues,
    totalCount,
    page: all ? 1 : page,
    limit: all ? totalCount : limit,
    totalPages: all ? 1 : Math.ceil(totalCount / limit),
  });
}

export async function PATCH(req: NextRequest) {
  const session = await getServerAuthSession();
  if (!session?.user?.tenantId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const body = await req.json();
  const { issueId, status, assignedTo } = body;
  if (!issueId) return NextResponse.json({ error: 'Missing issueId' }, { status: 400 });
  await connectToDatabase();
  const issue = await Issue.findOne({ _id: issueId, tenantId: session.user.tenantId });
  if (!issue) return NextResponse.json({ error: 'Issue not found' }, { status: 404 });
  const update: any = {};
  if (status !== undefined) {
    update.status = status;
    if (status === 'fixed' || status === 'wont_fix') update.resolvedAt = new Date();
    else update.resolvedAt = null;
  }
  if (assignedTo !== undefined) update.assignedTo = assignedTo || null;
  if (Object.keys(update).length === 0) return NextResponse.json({ error: 'No fields to update' }, { status: 400 });
  await Issue.updateOne({ _id: issueId }, { $set: update });
  return NextResponse.json({ success: true });
}
// app/api/issues/[id]/snippet/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';
import { Issue } from '@/models/Issue';
import { Tenant } from '@/models/Tenant';
import { getServerAuthSession } from '@/lib/auth';
import https from 'node:https';
import { URL } from 'node:url';

async function azureFetch(urlString: string, pat: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    const agent = new https.Agent({ rejectUnauthorized: false });
    const req = https.request({
      hostname: url.hostname,
      port: url.port || 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: { Authorization: `Basic ${Buffer.from(`:${pat}`).toString('base64')}` },
      agent,
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          resolve(data);
        } else {
          reject(new Error(`Erro Azure: ${res.statusCode} - ${data}`));
        }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerAuthSession();
  if (!session?.user?.tenantId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  await connectToDatabase();
  const issue = await Issue.findById(params.id);
  if (!issue || issue.tenantId !== session.user.tenantId) {
    return NextResponse.json({ error: 'Issue not found' }, { status: 404 });
  }

  const tenant = await Tenant.findById(issue.tenantId);
  if (!tenant || !tenant.azureSettings?.instanceUrl || !tenant.azureSettings?.pat) {
    return NextResponse.json({ error: 'Azure settings not configured for this Tenant' }, { status: 400 });
  }

  const { instanceUrl, azureCollection, pat } = tenant.azureSettings;
  const { project, repository, filePath, branch, lineNumber } = issue;

  if (!project || !repository || !filePath) {
    return NextResponse.json({ error: 'Missing project, repository or filePath' }, { status: 400 });
  }

  const baseUrl = instanceUrl.replace(/\/+$/, '');
  const cleanCollection = azureCollection.replace(/^\/+|\/+$/g, '');
  
  const url = `${baseUrl}/tfs/${cleanCollection}/${project}/_apis/git/repositories/${repository}/items?path=${encodeURIComponent(filePath)}&versionDescriptor.versionType=branch&versionDescriptor.version=${encodeURIComponent(branch)}&includeContent=true&api-version=7.1`;

  try {
    const fileContent = await azureFetch(url, pat);
    // Extrai o snippet: 10 linhas antes e 10 depois da linha onde foi encontrado
    const lines = fileContent.split('\n');
    const lineNum = lineNumber || 0; // Garante 0 caso não tenha número
    const start = Math.max(0, lineNum - 10);
    const end = Math.min(lines.length, lineNum + 10);
    const snippet = lines.slice(start, end).join('\n');

    return NextResponse.json({
      filePath,
      lineNumber,
      snippet,
      startLine: start + 1,
    });
    
  } catch (error: any) {
    console.error('Erro ao buscar snippet:', error.message);
    return NextResponse.json({ error: 'Failed to fetch code snippet' }, { status: 500 });
  }
}
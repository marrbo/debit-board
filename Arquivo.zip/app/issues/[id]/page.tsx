// app/issues/[id]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Code, ExternalLink } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism'; // Importado para o tema claro

export default function IssueDetailPage({ params }: { params: { id: string } }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [issue, setIssue] = useState<any>(null);
  const [snippetData, setSnippetData] = useState<{ snippet: string; lineNumber: number; startLine: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 🌗 Estado para alternar o tema do SyntaxHighlighter
  const [isDarkTheme, setIsDarkTheme] = useState(true);

  useEffect(() => {
    // Detecta a classe 'dark' no HTML ao montar e quando ela mudar
    const checkTheme = () => {
      const isDark = document.documentElement.classList.contains('dark');
      setIsDarkTheme(isDark);
    };
    
    checkTheme();
    
    // Cria um MutationObserver para monitorar a mudança da classe 'dark'
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    
    return () => observer.disconnect();
  }, []);

  const getLanguageFromExtension = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const map: Record<string, string> = {
      'cs': 'csharp', 'js': 'javascript', 'ts': 'typescript', 'py': 'python',
      'java': 'java', 'go': 'go', 'rb': 'ruby', 'rs': 'rust',
      'swift': 'swift', 'php': 'php', 'html': 'html', 'css': 'css',
      'json': 'json', 'xml': 'xml', 'yaml': 'yaml', 'yml': 'yaml',
      'md': 'markdown', 'sh': 'bash', 'bash': 'bash', 'ps1': 'powershell',
    };
    return map[ext || ''] || 'text';
  };

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) {
      router.push('/login');
      return;
    }

    const fetchIssueDetails = async () => {
      setLoading(true);
      try {
        const issueRes = await fetch(`/api/issues?id=${params.id}`);
        if (!issueRes.ok) {
          const errorData = await issueRes.json();
          throw new Error(errorData.error || 'Erro ao carregar Issue');
        }
        
        const data = await issueRes.json();
        let foundIssue = null;
        if (data._id) {
          foundIssue = data;
        } else if (data.issues && Array.isArray(data.issues)) {
          foundIssue = data.issues.find((i: any) => i._id === params.id);
        }

        if (!foundIssue) {
          throw new Error('Issue não encontrada.');
        }
        
        setIssue(foundIssue);

        const snippetRes = await fetch(`/api/issues/${params.id}/snippet`);
        if (snippetRes.ok) {
          const snippetData = await snippetRes.json();
          setSnippetData(snippetData);
        } else {
          console.warn('Não foi possível carregar o snippet');
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchIssueDetails();
  }, [params.id, session, status, router]);

  if (loading) return <div className="flex justify-center py-12 text-gray-500 dark:text-slate-400">Carregando detalhes...</div>;
  
  if (error) return (
    <div className="w-full px-4 py-6">
      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700/30 rounded-xl p-6 text-red-700 dark:text-red-300">
        <p className="font-medium">Erro ao carregar Issue:</p>
        <p className="text-sm mt-1">{error}</p>
      </div>
    </div>
  );

  if (!issue) return <div className="text-gray-500 dark:text-slate-400 text-center py-12">Issue não encontrada.</div>;

  const azureUrl = `${session?.user?.azureSettings?.instanceUrl || ''}/tfs/${session?.user?.azureSettings?.azureCollection || ''}/${issue.project}/_git/${issue.repository}?path=${issue.filePath}&_a=contents`;

  return (
    <div className="w-full px-4 py-6 space-y-6 mx-auto">
      <div className="flex items-center justify-between">
        <Link href="/issues" className="flex items-center gap-2 text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white transition-colors w-fit">
          <ArrowLeft className="w-4 h-4" /> Voltar para Issues
        </Link>
        {azureUrl && (
          <a href={azureUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 text-sm font-medium transition-colors">
            Abrir no Azure <ExternalLink className="w-4 h-4" />
          </a>
        )}
      </div>

      {/* Painel de Informações */}
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-6 shadow-sm transition-colors">
        <div className="flex justify-between items-start mb-4">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{issue.fileName}</h1>
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${issue.status === 'open' ? 'bg-red-100 dark:bg-red-500/20 text-red-600 dark:text-red-400' : issue.status === 'fixed' ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' : issue.status === 'recurring' ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400' : 'bg-gray-100 dark:bg-slate-500/20 text-gray-600 dark:text-slate-400'}`}>
            {issue.status.toUpperCase()}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm border-t border-gray-200 dark:border-slate-700 pt-4">
          <div><span className="text-gray-500 dark:text-slate-400">Categoria:</span> <span className="text-gray-900 dark:text-white font-medium">{issue.category}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Projeto:</span> <span className="text-gray-900 dark:text-white font-medium">{issue.project}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Repositório:</span> <span className="text-gray-900 dark:text-white font-medium">{issue.repository}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Branch:</span> <span className="text-gray-900 dark:text-white font-medium">{issue.branch}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Caminho:</span> <span className="text-gray-900 dark:text-white font-mono text-xs">{issue.filePath}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Hits:</span> <span className="text-gray-900 dark:text-white font-bold text-amber-600 dark:text-amber-400">{issue.hitCount}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">Primeira ocorrência:</span> <span className="text-gray-900 dark:text-white">{new Date(issue.firstSeen).toLocaleDateString()}</span></div>
          <div><span className="text-gray-500 dark:text-slate-400">SLA Vence:</span> <span className="text-gray-900 dark:text-white">{new Date(issue.slaDueAt).toLocaleDateString()}</span></div>
        </div>
      </div>

      {/* Painel do Snippet com SyntaxHighlighter que alterna tema */}
      {snippetData?.snippet ? (
        <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-6 shadow-sm overflow-hidden transition-colors">
          <div className="flex items-center gap-2 mb-3 text-gray-700 dark:text-slate-300">
            <Code className="w-4 h-4" />
            <span className="font-medium">Trecho de Código</span>
            <span className="text-xs text-gray-500 dark:text-slate-500 ml-2">(Linhas {snippetData.startLine} - {snippetData.startLine + snippetData.snippet.split('\n').length - 1})</span>
          </div>
          <div className="rounded-lg border border-gray-300 dark:border-slate-800 overflow-hidden transition-colors">
            <SyntaxHighlighter
              language={getLanguageFromExtension(issue.fileName)}
              style={isDarkTheme ? oneDark : oneLight} // 🌗 Alternância dinâmica aqui
              showLineNumbers={true}
              customStyle={{ 
                backgroundColor: isDarkTheme ? '#0f172a' : '#f8fafc', 
                padding: '1.5rem', 
                fontSize: '0.875rem', 
                margin: 0,
                transition: 'background-color 0.2s ease'
              }}
              lineProps={(lineNumber) => {
                const globalLine = (snippetData.startLine || 1) + lineNumber - 1;
                if (globalLine === snippetData.lineNumber) {
                  return { 
                    style: { 
                      display: 'block', 
                      backgroundColor: isDarkTheme ? 'rgba(239, 68, 68, 0.25)' : 'rgba(239, 68, 68, 0.15)', 
                      borderLeft: `4px solid #ef4444`, 
                      paddingLeft: '1rem', 
                      marginLeft: '-1.5rem', 
                      paddingRight: '1rem', 
                      marginRight: '-1.5rem' 
                    } 
                  };
                }
                return {};
              }}
            >
              {snippetData.snippet}
            </SyntaxHighlighter>
          </div>
        </div>
      ) : (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 rounded-xl p-4 text-amber-700 dark:text-amber-200 text-sm transition-colors">
          Nenhum trecho de código disponível para esta Issue.
        </div>
      )}
    </div>
  );
}
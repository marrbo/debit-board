import path from 'path';
import { getWikiTree } from '@/lib/wiki-utils';
import { WikiSidebar } from '@/components/wiki/WikiSidebar';

export default async function WikiLayout({ children }: { children: React.ReactNode }) {
  const wikiPath = path.join(process.cwd(), 'content', 'wiki');
  const tree = getWikiTree(wikiPath);

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden transition-colors duration-200">
      
      {/* Sidebar da Wiki (Estilo Escuro Apple) */}
      <aside className="w-64 border-r border-[#38383A] h-full overflow-y-auto p-4 bg-[#1C1C1E] flex-shrink-0 text-[#F5F5F7] transition-colors">
        <div className="mb-4 px-2 font-bold text-lg text-[#F5F5F7]">Wiki Explorer</div>
        <WikiSidebar items={tree} />
      </aside>

      {/* 📄 ÁREA DA WIKI (Fundo Off-White Apple no claro, Preto no escuro) */}
      <main className="flex-1 h-full overflow-y-auto p-4 bg-[#F5F5F7] dark:bg-black text-[#1C1C1E] dark:text-[#F5F5F7] transition-colors duration-200">
        {children}
      </main>
      
    </div>
  );
}
// app/settings/repositories/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { RefreshCw, Search } from 'lucide-react';
import PageHeader from '@/components/PageHeader';

interface Project {
  _id: string;
  name: string;
  teamIds: string[];
  createdAt: string;
}

export default function RepositoriesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [repos, setRepos] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchRepos = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/projects');
      if (res.ok) {
        const data = await res.json();
        setRepos(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (status === 'authenticated') {
      fetchRepos();
    }
  }, [status]);

  if (status === 'loading') return <div className="py-10 text-gray-500 dark:text-slate-400">Carregando...</div>;
  if (!session) { router.push('/login'); return null; }

  const filteredRepos = repos.filter(r => r.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="w-full space-y-4">
      <PageHeader
        title="Projetos"
        subtitle="Gerencie os projetos sincronizados automaticamente pelas buscas."
        actions={
          <button onClick={fetchRepos} className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 text-gray-900 dark:text-white px-3 py-1.5 rounded text-sm font-medium">
            <RefreshCw className="w-4 h-4" /> Sincronizar
          </button>
        }
      />

      <div className="relative mb-4">
        <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
        <input
          type="text"
          placeholder="Filtrar projetos..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
        />
      </div>

      {loading ? (
        <div className="py-12 text-center text-gray-500 dark:text-slate-400">Carregando...</div>
      ) : filteredRepos.length === 0 ? (
        <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-12 text-center text-gray-500 dark:text-slate-400">
          {repos.length === 0 ? 'Nenhum repositório encontrado. Execute uma busca no Azure Search para sincronizar automaticamente.' : 'Nenhum repositório corresponde ao filtro.'}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden w-full">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-900 text-gray-500 dark:text-slate-400 border-b border-gray-200 dark:border-slate-700">
              <tr>
                <th className="p-4">Nome do Projeto</th>
                <th className="p-4 text-right">ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {filteredRepos.map(repo => (
                <tr key={repo._id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="p-4 font-medium text-gray-900 dark:text-white flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-slate-700 flex items-center justify-center text-[10px] text-gray-900 dark:text-white font-bold">
                      {repo.name.charAt(0).toUpperCase()}
                    </div>
                    {repo.name}
                  </td>
                  <td className="p-4 text-right font-mono text-gray-500 dark:text-slate-400 text-xs">{repo._id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
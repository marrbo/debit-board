// app/settings/page.tsx
'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import PageHeader from '@/components/PageHeader';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { settingsMenuItems } from '@/lib/settingsMenu';

export default function SettingsDashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  // Redireciona para a primeira aba (Teams) por padrão, estilo Sentry
  useEffect(() => {
    if (status === 'authenticated') {
      router.replace('/settings/profile/user');
    }
  }, [status, router]);

  if (status === 'loading') return <div className="py-10 text-gray-500 dark:text-slate-400">Carregando...</div>;

  return (
    <div className="w-full space-y-6 max-w-4xl mx-auto">
      <PageHeader title="Settings" subtitle="Gerencie seu tenant e integrações." />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {settingsMenuItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="group bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-5 hover:bg-slate-700/40 transition-all flex items-center justify-between"
          >
            <div className="flex items-start gap-4">
              <div className="p-3 bg-slate-900 rounded-lg text-gray-500 dark:text-slate-400 group-hover:text-blue-400 transition-colors">
                <item.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white group-hover:text-blue-400 transition-colors">{item.label}</h3>
                <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">{item.label}</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
          </Link>
        ))}
      </div>
    </div>
  );
}
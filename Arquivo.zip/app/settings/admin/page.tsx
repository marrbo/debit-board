// app/admin/page.tsx
import { getServerAuthSession } from "@/lib/auth";
import { connectToDatabase } from "@/lib/mongodb";
import { Tenant } from "@/models/Tenant";
import { User } from "@/models/User";
import { redirect } from "next/navigation";
import AdminTabs from "./AdminTabs";
import { UserCog } from "lucide-react";

export default async function AdminPage() {
  const session = await getServerAuthSession();
  // const adminEmail = process.env.ADMIN_EMAIL;

  // // Protege a rota: apenas o admin pode acessar
  // if (!session || session.user?.email !== adminEmail) {
  //   redirect("/");
  // }

  await connectToDatabase();
  const tenants = await Tenant.find({}).sort({ name: 1 }).lean();
  const users = await User.find({}).sort({ name: 1 }).lean();

  // Serializa para o cliente (evita erros de serialização)
  const serializedTenants = JSON.parse(JSON.stringify(tenants));
  const serializedUsers = JSON.parse(JSON.stringify(users));

  return (
    <div className="w-full mx-auto">
    
     <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <UserCog className="w-5 h-5" />
            Admin
        </h1>
    </div>

      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-slate-700 flex items-center gap-3 bg-white dark:bg-slate-800/80">
            <p className="text-xs text-gray-500 dark:text-slate-400">Gerencie Tenants e Usuários</p>
        </div>

        {/* Componente cliente com as abas */}
        <AdminTabs tenants={serializedTenants} users={serializedUsers} />
      </div>
    </div>
  );
}
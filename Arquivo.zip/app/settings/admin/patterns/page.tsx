// app/settings/admin/patterns/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Pencil, Trash2, Plus } from 'lucide-react';
import PageHeader from '@/components/PageHeader';

export default function PatternsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [patterns, setPatterns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPattern, setEditingPattern] = useState<any>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    name: '', queryPattern: '', severity: 'medium', category: '', description: '',
    slaHours: 72, externalId: '', externalLink: '', reference: '', enabled: true
  });

  useEffect(() => {
    if (status === 'loading') return;
    if (!session || session.user?.email !== process.env.NEXT_PUBLIC_ADMIN_EMAIL) router.push('/');
    fetchPatterns();
  }, [session, status, router]);

  const fetchPatterns = async () => {
    setLoading(true);
    const res = await fetch('/api/admin/patterns');
    if (res.ok) setPatterns(await res.json());
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editingPattern ? 'PUT' : 'POST';
    const url = editingPattern ? `/api/admin/patterns?id=${editingPattern._id}` : '/api/admin/patterns';
    const res = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      setEditingPattern(null); setShowCreate(false); setForm({
        name: '', queryPattern: '', severity: 'medium', category: '', description: '',
        slaHours: 72, externalId: '', externalLink: '', reference: '', enabled: true
      });
      fetchPatterns();
    } else alert('Erro ao salvar padrão.');
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Remover este padrão?')) return;
    await fetch(`/api/admin/patterns?id=${id}`, { method: 'DELETE' });
    fetchPatterns();
  };

  if (loading) return <div className="py-10 text-gray-500 dark:text-slate-400">Carregando...</div>;

  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SAST Patterns</h1>
        <button onClick={() => { setForm({ name: '', queryPattern: '', severity: 'medium', category: '', description: '', slaHours: 72, externalId: '', externalLink: '', reference: '', enabled: true }); setShowCreate(true); }} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-gray-900 dark:text-white px-4 py-2 rounded-lg text-sm font-medium">
          <Plus className="w-4 h-4" /> Novo Padrão
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-900 text-gray-500 dark:text-slate-400 border-b border-gray-200 dark:border-slate-700"><tr>
            <th className="p-4">Nome</th><th className="p-4">Categoria</th><th className="p-4">Severidade</th>
            <th className="p-4 text-center">SLA (h)</th><th className="p-4 text-center">Ativo</th><th className="p-4 text-right">Ações</th>
          </tr></thead>
          <tbody className="divide-y divide-slate-700">
            {patterns.map(p => (
              <tr key={p._id} className="hover:bg-slate-700/30 transition-colors">
                <td className="p-4 font-medium text-gray-900 dark:text-white">{p.name}</td>
                <td className="p-4 text-slate-300">{p.category}</td>
                <td className="p-4"><span className={`px-2 py-0.5 rounded text-xs font-bold ${p.severity === 'critical' ? 'bg-red-900/40 text-red-400' : p.severity === 'high' ? 'bg-orange-900/40 text-orange-400' : 'bg-blue-900/40 text-blue-400'}`}>{p.severity}</span></td>
                <td className="p-4 text-center text-slate-300">{p.slaHours}</td>
                <td className="p-4 text-center"><span className={`px-2 py-0.5 rounded text-xs ${p.enabled ? 'bg-emerald-900/40 text-emerald-400' : 'bg-slate-700/40 text-gray-500 dark:text-slate-400'}`}>{p.enabled ? 'Sim' : 'Não'}</span></td>
                <td className="p-4 text-right space-x-2">
                  <button onClick={() => { setEditingPattern(p); setForm(p); }} className="text-blue-400 hover:text-blue-300"><Pencil className="w-4 h-4 inline" /></button>
                  <button onClick={() => handleDelete(p._id)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4 inline" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal de Criação/Edição */}
      {(showCreate || editingPattern) && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl w-full max-w-lg p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">{editingPattern ? 'Editar Padrão' : 'Criar Novo Padrão'}</h2>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">Nome *</label><input type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" required /></div>
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">Query Pattern *</label><input type="text" value={form.queryPattern} onChange={e => setForm({...form, queryPattern: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" required /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">Categoria</label><input type="text" value={form.category} onChange={e => setForm({...form, category: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" /></div>
                <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">Severidade</label><select value={form.severity} onChange={e => setForm({...form, severity: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option></select></div>
              </div>
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">SLA (horas)</label><input type="number" value={form.slaHours} onChange={e => setForm({...form, slaHours: parseInt(e.target.value)})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" /></div>
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">Descrição</label><textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" rows={2}></textarea></div>
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">External ID (ex: CVE-2021-44228)</label><input type="text" value={form.externalId} onChange={e => setForm({...form, externalId: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" /></div>
              <div><label className="block text-xs font-semibold text-gray-500 dark:text-slate-400">External Link (URL)</label><input type="url" value={form.externalLink} onChange={e => setForm({...form, externalLink: e.target.value})} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm" /></div>
              <div className="flex items-center gap-2"><input type="checkbox" id="enabled" checked={form.enabled} onChange={e => setForm({...form, enabled: e.target.checked})} className="w-4 h-4 rounded bg-slate-900 border-gray-200 dark:border-slate-700" /><label htmlFor="enabled" className="text-sm text-slate-300">Ativo</label></div>
              <div className="flex justify-end gap-2 pt-2"><button type="button" onClick={() => { setShowCreate(false); setEditingPattern(null); }} className="px-4 py-2 text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white">Cancelar</button><button type="submit" className="bg-blue-600 hover:bg-blue-500 text-gray-900 dark:text-white px-4 py-2 rounded font-medium">Salvar</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
// app/settings/admin/tenants/[id]/azure-settings/page.tsx
import { getServerAuthSession } from "@/lib/auth";
import { connectToDatabase } from "@/lib/mongodb";
import { Tenant } from "@/models/Tenant";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { Settings } from "lucide-react";

export default async function TenantAzureSettings({ params }: { params: { id: string } }) {
  const session = await getServerAuthSession();
  const adminEmail = process.env.ADMIN_EMAIL;

  // 1. Bloqueia acesso não-admin
  if (session?.user?.email !== adminEmail) {
    redirect("/");
  }

  // 2. Conecta ao banco
  await connectToDatabase();

  // 🔥 CORREÇÃO: O Mongoose aceita buscar por string diretamente. 
  // Se não achar pelo ObjectId (ou ID customizado), busca pelo UUID.
  let tenant: any = null;

  try {
    tenant = await Tenant.findById(params.id);
  } catch {
    if (!tenant) {
      tenant = await Tenant.findOne({ uuid: params.id });
    }
  }

  // 3. Se ainda não encontrou, exibe um erro visual na tela
  if (!tenant) {
    return (
      <div className="w-full mx-auto py-8">
        <div className="bg-red-900/20 border border-red-700/30 rounded-xl p-6 text-red-300">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Tenant não encontrado</h2>
          <p className="text-sm">
            O Tenant com o ID ou UUID <strong>{params.id}</strong> não existe.
            Verifique a URL ou volte para o painel.
          </p>
          <a href="/admin" className="mt-4 inline-block bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg text-gray-900 dark:text-white text-sm">Voltar para Admin</a>
        </div>
      </div>
    );
  }

  // Server Action para salvar
  async function updateAzureSettings(formData: FormData) {
    "use server";
    const settings = {
      instanceUrl: formData.get("instanceUrl"),
      azureCollection: formData.get("azureCollection"),
      pat: formData.get("pat"),
      username: formData.get("username"),
      defaultProject: formData.get("defaultProject"),
      defaultRepository: formData.get("defaultRepository"),
      reportTitle: formData.get("reportTitle"),
      ignoreTlsErrors: formData.get("ignoreTlsErrors") === "on",
    };
    await connectToDatabase();
    await Tenant.findByIdAndUpdate(tenant?._id, { azureSettings: settings });
    
    revalidatePath("/settings/admin");
    redirect("/settings/admin");
  }

  return (
    <div className="w-full mx-auto">
      <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Settings className="w-5 h-5" /> 
              Configurações Azure
          </h1>
      </div>
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          {tenant.name}
        </h2>
        <p className="text-sm text-gray-500 dark:text-slate-400 mb-6">
          Essas configurações serão utilizadas por todos os usuários vinculados a este Tenant.
        </p>

        <form action={updateAzureSettings} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">URL da Instância</label>
              <input type="url" name="instanceUrl" defaultValue={tenant.azureSettings?.instanceUrl || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" required />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">Coleção</label>
              <input type="text" name="azureCollection" defaultValue={tenant.azureSettings?.azureCollection || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" required />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">Personal Access Token (PAT)</label>
            <input type="password" name="pat" defaultValue={tenant.azureSettings?.pat || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" required />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">Usuário (Opcional)</label>
              <input type="text" name="username" defaultValue={tenant.azureSettings?.username || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">Projeto Padrão (Opcional)</label>
              <input type="text" name="defaultProject" defaultValue={tenant.azureSettings?.defaultProject || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">Título do Relatório (Opcional)</label>
            <input type="text" name="reportTitle" defaultValue={tenant.azureSettings?.reportTitle || ''} className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500" />
          </div>

          <div className="flex items-center gap-3 py-2">
            <input type="checkbox" id="ignoreTlsErrors" name="ignoreTlsErrors" defaultChecked={tenant.azureSettings?.ignoreTlsErrors || false} className="w-4 h-4 bg-slate-900 border border-gray-200 dark:border-slate-700 rounded focus:ring-2 focus:ring-blue-500 cursor-pointer" />
            <label htmlFor="ignoreTlsErrors" className="text-sm text-slate-300 cursor-pointer select-none">
              Ignorar erros de certificado TLS (Self-signed CA / Proxy interno)
            </label>
          </div>

          <div className="flex justify-end pt-4 border-t border-gray-200 dark:border-slate-700">
            <button type="submit" className="bg-blue-600 hover:bg-blue-500 text-gray-900 dark:text-white px-5 py-2 rounded-lg text-sm font-medium transition-all">
              Salvar Configurações do Tenant
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
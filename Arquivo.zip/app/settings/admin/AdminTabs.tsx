"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { Pencil, Trash2, Plus, X, Contact, Settings } from "lucide-react";
import {
  createTenant,
  updateTenant,
  deleteTenant,
  assignUsersToTenant,
  updateUser,
  toggleTenantStatus,
  toggleUserStatus,
  createUser,
} from "./actions";

export default function AdminTabs({
  tenants,
  users,
}: {
  tenants: any[];
  users: any[];
}) {
  const [activeTab, setActiveTab] = useState<"tenants" | "users">("tenants");

  // Filtros
  const [filterTenant, setFilterTenant] = useState<string>("all");
  const [filterPending, setFilterPending] = useState<boolean>(false);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [bulkTargetTenant, setBulkTargetTenant] = useState<string>("");
  const [loading, setLoading] = useState(false);

  // Modais
  const [editingTenant, setEditingTenant] = useState<any>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [showCreateUser, setShowCreateUser] = useState(false);

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const tenantMatch =
        filterTenant === "all" || user.tenantId === filterTenant;
      const pendingMatch = filterPending ? user.tenantId === "pending" : true;
      return tenantMatch && pendingMatch;
    });
  }, [users, filterTenant, filterPending]);

  const handleBulkAssign = async () => {
    if (selectedUsers.length === 0 || !bulkTargetTenant) return;
    if (
      !confirm(
        `Atribuir ${selectedUsers.length} usuários ao tenant selecionado?`
      )
    )
      return;
    setLoading(true);
    await assignUsersToTenant(selectedUsers, bulkTargetTenant);
    setSelectedUsers([]);
    setBulkTargetTenant("");
    setLoading(false);
  };

  const handleDeleteTenant = async (id: string) => {
    if (!confirm("Deletar este tenant? Essa ação é irreversível.")) return;
    await deleteTenant(id);
  };

  const handleToggleTenant = async (
    id: string,
    currentStatus: boolean | undefined
  ) => {
    const isActive = currentStatus ?? true;
    if (!confirm(`Deseja ${isActive ? "desativar" : "ativar"} este tenant?`))
      return;
    await toggleTenantStatus(id, !isActive);
  };

  const handleToggleUser = async (
    sub: string,
    currentStatus: boolean | undefined
  ) => {
    const isActive = currentStatus ?? true;
    if (!confirm(`Deseja ${isActive ? "desativar" : "ativar"} este usuário?`))
      return;
    await toggleUserStatus(sub, !isActive);
  };

  const handleImpersonate = async (sub: string) => {
    if (!confirm("Deseja se passar por este usuário?")) return;
    const res = await fetch("/api/admin/impersonate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: sub }),
    });
    if (res.ok) window.location.href = "/stats";
    else alert("Erro ao iniciar impersonação.");
  };

  return (
    <div className="p-6">
      {/* Navegação por Abas */}
      <div className="flex border-b border-gray-200 dark:border-slate-700 bg-slate-900/50">
        <button
          onClick={() => setActiveTab("tenants")}
          className={`px-6 py-3 text-sm font-medium transition-colors ${
            activeTab === "tenants"
              ? "border-b-2 border-blue-500 text-gray-900 dark:text-white bg-white dark:bg-slate-800"
              : "text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
          }`}
        >
          Tenants
        </button>
        <button
          onClick={() => setActiveTab("users")}
          className={`px-6 py-3 text-sm font-medium transition-colors ${
            activeTab === "users"
              ? "border-b-2 border-blue-500 text-gray-900 dark:text-white bg-white dark:bg-slate-800"
              : "text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
          }`}
        >
          Usuários
        </button>
      </div>

      {/* -- ABA TENANTS -- */}
      {activeTab === "tenants" && (
        <div className="pt-6 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Gerenciar Tenants
            </h3>
            <button
              onClick={() => setShowCreate(true)}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 px-4 py-2 rounded-lg text-sm font-medium text-gray-900 dark:text-white"
            >
              <Plus className="w-4 h-4" /> Novo Tenant
            </button>
          </div>
          <div className="overflow-x-auto border border-gray-200 dark:border-slate-700 rounded-lg">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-gray-500 dark:text-slate-400 border-b border-gray-200 dark:border-slate-700">
                <tr>
                  <th className="p-4">Empresa</th>
                  <th className="p-4">UUID</th>
                  <th className="p-4">Domínio</th>
                  <th className="p-4 text-center">Ativo</th>
                  <th className="p-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {tenants.map((t) => {
                  const isActive = t.isActive ?? true;
                  return (
                    <tr
                      key={t._id}
                      className="hover:bg-slate-700/30 transition-colors"
                    >
                      <td className="p-4 font-medium text-gray-900 dark:text-white">{t.name}</td>
                      <td className="p-4 font-mono text-gray-500 dark:text-slate-400 text-xs">
                        {t.uuid}
                      </td>
                      <td className="p-4 font-mono text-gray-500 dark:text-slate-400">
                        {t.dominio || "-"}
                      </td>
                      <td className="p-4 text-center">
                        <button
                          onClick={() => handleToggleTenant(t._id, isActive)}
                          className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                            isActive
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                              : "bg-red-500/20 text-red-400 border border-red-500/40"
                          }`}
                        >
                          {isActive ? "Ativo" : "Inativo"}
                        </button>
                      </td>
                      <td className="p-4 text-right flex items-center justify-end gap-2">
                        <Link 
                            href={`/settings/admin/tenants/${t.uuid}/azure-settings`} 
                            className="text-emerald-400 hover:text-emerald-300 transition-colors"
                            title="Configurações do Azure"
                            >
                            <Settings className="w-4 h-4" />
                        </Link>

                        <button
                          onClick={() => setEditingTenant(t)}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteTenant(t._id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* -- ABA USUÁRIOS -- */}
      {activeTab === "users" && (
        <div className="pt-6 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-end justify-between">
            <div className="flex flex-wrap items-center gap-4">
              <div className="space-y-1">
                <label className="text-xs text-gray-500 dark:text-slate-400">
                  Filtrar por Tenant
                </label>
                <select
                  value={filterTenant}
                  onChange={(e) => setFilterTenant(e.target.value)}
                  className="bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-2 text-sm text-slate-200 w-48"
                >
                  <option value="all">Todos</option>
                  <option value="pending">⏳ Pendentes</option>
                  {tenants.map((t) => (
                    <option key={t._id} value={t._id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer pt-2 md:pt-5">
                <input
                  type="checkbox"
                  checked={filterPending}
                  onChange={(e) => setFilterPending(e.target.checked)}
                  className="w-4 h-4 bg-slate-900 border-gray-200 dark:border-slate-700 rounded"
                />
                Apenas Pendentes
              </label>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowCreateUser(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-sm font-medium text-gray-900 dark:text-white"
              >
                <Plus className="w-4 h-4" /> Novo Usuário
              </button>

              {selectedUsers.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 bg-blue-900/30 p-3 rounded-lg border border-blue-700/40">
                  <span className="text-sm text-blue-300">
                    {selectedUsers.length} selecionado(s)
                  </span>
                  <select
                    value={bulkTargetTenant}
                    onChange={(e) => setBulkTargetTenant(e.target.value)}
                    className="bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-2 py-1 text-sm text-slate-200"
                  >
                    <option value="">Atribuir ao Tenant...</option>
                    {tenants.map((t) => (
                      <option key={t._id} value={t._id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleBulkAssign}
                    disabled={!bulkTargetTenant || loading}
                    className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-gray-900 dark:text-white px-3 py-1 rounded text-sm"
                  >
                    {loading ? "Processando..." : "Aplicar"}
                  </button>
                  <button
                    onClick={() => setSelectedUsers([])}
                    className="text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="border border-gray-200 dark:border-slate-700 rounded-lg overflow-hidden">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-gray-500 dark:text-slate-400 border-b border-gray-200 dark:border-slate-700">
                <tr>
                  <th className="p-3 w-10">
                    <input
                      type="checkbox"
                      checked={
                        selectedUsers.length === filteredUsers.length &&
                        filteredUsers.length > 0
                      }
                      onChange={(e) =>
                        setSelectedUsers(
                          e.target.checked
                            ? filteredUsers.map((u) => u.sub)
                            : []
                        )
                      }
                    />
                  </th>
                  <th className="p-3">Nome</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Tenant</th>
                  <th className="p-3 text-center">Onboard</th>
                  <th className="p-3 text-center">Ativo</th>
                  <th className="p-3 text-right w-24">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {filteredUsers.map((u) => {
                  const isActive = u.isActive ?? true;
                  return (
                    <tr key={u._id} className="hover:bg-slate-700/30">
                      <td className="p-3">
                        <input
                          type="checkbox"
                          checked={selectedUsers.includes(u.sub)}
                          onChange={(e) =>
                            setSelectedUsers(
                              e.target.checked
                                ? [...selectedUsers, u.sub]
                                : selectedUsers.filter((id) => id !== u.sub)
                            )
                          }
                        />
                      </td>
                      <td className="p-3 text-gray-900 dark:text-white">{u.name || "Sem Nome"}</td>
                      <td className="p-3 text-slate-300">{u.email}</td>
                      <td className="p-3 text-gray-500 dark:text-slate-400">
                        {u.tenantId === "pending" ? (
                          <span className="text-amber-400 text-xs font-bold">
                            Pendente
                          </span>
                        ) : (
                          tenants.find((t) => t._id === u.tenantId)?.name ||
                          u.tenantId
                        )}
                      </td>
                      <td className="p-3 text-center text-xs">
                        <span
                          className={`px-2 py-1 rounded border ${
                            u.onboardingCompleted
                              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                              : "bg-amber-500/20 text-amber-400 border-amber-500/40"
                          }`}
                        >
                          {u.onboardingCompleted ? "Concluído" : "Pendente"}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleToggleUser(u.sub, isActive)}
                          className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                            isActive
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30"
                              : "bg-red-500/20 text-red-400 border border-red-500/40 hover:bg-red-500/30"
                          }`}
                        >
                          {isActive ? "Ativo" : "Inativo"}
                        </button>
                      </td>
                      <td className="p-3 text-right flex items-center justify-end gap-1">
                        <button
                          onClick={() => setEditingUser(u)}
                          className="text-blue-400 hover:text-blue-300"
                          title="Editar"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleImpersonate(u.sub)}
                          className="text-purple-400 hover:text-purple-300"
                          title="Login como"
                        >
                          <Contact className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* -- Modais -- */}
      {showCreate && (
        <TenantForm
          onClose={() => setShowCreate(false)}
          action={createTenant}
          title="Criar Novo Tenant"
        />
      )}
      {editingTenant && (
        <TenantForm
          onClose={() => setEditingTenant(null)}
          action={updateTenant.bind(null, editingTenant._id)}
          title="Editar Tenant"
          initialName={editingTenant.name}
          initialDomain={editingTenant.dominio || ""}
        />
      )}
      {editingUser && (
        <UserEditForm
          user={editingUser}
          tenants={tenants}
          onClose={() => setEditingUser(null)}
        />
      )}
      {showCreateUser && (
        <UserCreateForm
          onClose={() => setShowCreateUser(false)}
          tenants={tenants}
        />
      )}
    </div>
  );
}

// ============================================================
// COMPONENTES DOS MODAIS
// ============================================================

function TenantForm({
  onClose,
  action,
  title,
  initialName = "",
  initialDomain = "",
}: {
  onClose: () => void;
  action: (formData: FormData) => Promise<void>;
  title: string;
  initialName?: string;
  initialDomain?: string;
}) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">{title}</h2>
        <form
          action={action}
          onSubmit={() => setTimeout(onClose, 200)}
          className="space-y-4"
        >
          <input
            type="text"
            name="name"
            defaultValue={initialName}
            placeholder="Nome da Empresa"
            className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
            required
          />
          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Domínio (ex: empresa.com.br)
            </label>
            <input
              type="text"
              name="dominio"
              defaultValue={initialDomain}
              placeholder="empresa.com.br"
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-500 text-gray-900 dark:text-white px-4 py-2 rounded font-medium transition-colors"
            >
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function UserEditForm({
  user,
  tenants,
  onClose,
}: {
  user: any;
  tenants: any[];
  onClose: () => void;
}) {
  const [isUpdating, setIsUpdating] = useState(false);
  const currentTenant = user.tenantId === "pending" ? "pending" : user.tenantId;

  const handleUpdateUser = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsUpdating(true);
    const formData = new FormData(e.currentTarget);

    try {
      await updateUser(user.sub, formData);
      onClose();
    } catch (err: any) {
      alert("Erro ao salvar as alterações: " + (err.message || "Erro desconhecido"));
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Editar Usuário</h2>
        <p className="text-xs text-gray-500 dark:text-slate-400 mb-4">
          Altere os dados ou force a conclusão do onboarding.
        </p>

        <form onSubmit={handleUpdateUser} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Nome
            </label>
            <input
              type="text"
              name="name"
              defaultValue={user.name || ""}
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              defaultValue={user.email || ""}
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Vincular ao Tenant
            </label>
            <select
              name="tenantId"
              defaultValue={currentTenant}
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
            >
              <option value="pending">⏳ Pendente</option>
              {tenants.map((t) => (
                <option key={t._id} value={t._id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-3 py-2">
            <input
              type="checkbox"
              id="onboardingCompleted"
              name="onboardingCompleted"
              value="true"
              defaultChecked={user.onboardingCompleted === true}
              className="w-4 h-4 bg-slate-900 border border-gray-200 dark:border-slate-700 rounded focus:ring-2 focus:ring-blue-500 cursor-pointer"
            />
            <label
              htmlFor="onboardingCompleted"
              className="text-sm text-slate-300 cursor-pointer select-none"
            >
              Onboarding concluído (Libera acesso ao Dashboard)
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
              disabled={isUpdating}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isUpdating}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-gray-900 dark:text-white px-4 py-2 rounded font-medium transition-colors"
            >
              {isUpdating ? "Salvando..." : "Salvar Alterações"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function UserCreateForm({
  onClose,
  tenants,
}: {
  onClose: () => void;
  tenants: any[];
}) {
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateUser = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsCreating(true);
    const formData = new FormData(e.currentTarget);
    try {
      await createUser(formData);
      onClose();
    } catch (err: any) {
      alert("Erro ao criar usuário: " + (err.message || "Erro desconhecido"));
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Criar Novo Usuário</h2>
        <p className="text-xs text-gray-500 dark:text-slate-400 mb-4">
          Adicione um usuário manualmente para testar a impersonação.
        </p>
        <form onSubmit={handleCreateUser} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Nome (Opcional)
            </label>
            <input
              type="text"
              name="name"
              placeholder="João da Silva"
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              E-mail *
            </label>
            <input
              type="email"
              name="email"
              placeholder="joao@sefaz.ba.gov.br"
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Vincular ao Tenant *
            </label>
            <select
              name="tenantId"
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-4 py-2 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
              required
            >
              <option value="">Selecione um Tenant...</option>
              {tenants.map((t) => (
                <option key={t._id} value={t._id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:text-white"
              disabled={isCreating}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isCreating}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-gray-900 dark:text-white px-4 py-2 rounded font-medium transition-colors"
            >
              {isCreating ? "Criando..." : "Criar Usuário"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
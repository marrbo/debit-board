// app/settings/teams/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Plus, Trash2, UserPlus, Users } from 'lucide-react';

export default function TeamsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [teams, setTeams] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [newTeamName, setNewTeamName] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    const teamsRes = await fetch('/api/teams');
    if (teamsRes.ok) setTeams(await teamsRes.json());

    const usersRes = await fetch('/api/users');
    if (usersRes.ok) setUsers(await usersRes.json());
  };

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) router.push('/login');
    fetchData();
  }, [session, status, router]);

  const createTeam = async () => {
    if (!newTeamName) return;
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newTeamName }),
    });
    setNewTeamName('');
    fetchData();
  };

  const deleteTeam = async (id: string) => {
    if (!confirm('Deletar este time?')) return;
    await fetch(`/api/teams?id=${id}`, { method: 'DELETE' });
    fetchData();
  };

  const updateTeamMembers = async (teamId: string, userId: string, action: 'add' | 'remove') => {
    await fetch(`/api/teams/${teamId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, action }),
    });
    fetchData();
  };

  if (status === 'loading') return <div className="text-gray-500 dark:text-slate-400 py-10">Carregando times...</div>;

  return (
    <div className="space-y-6 w-full mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            <Users className="w-5 h-5 inline-block mr-2" />
            Repositórios
        </h1>
      </div>

      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-6">
        <div className="flex justify-between items-center mb-4 border-b border-gray-200 dark:border-slate-700 pb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Gerenciar Repositórios</h2>
          <div className="flex gap-2">
            <input
              type="text"
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              placeholder="Nome do Repositório"
              className="bg-slate-900 border border-gray-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-200"
            />
            <button
              onClick={createTeam}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-gray-900 dark:text-white px-3 py-1.5 rounded text-sm font-medium transition-colors"
            >
              <Plus className="w-4 h-4" /> Criar Repositório
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {teams.map((team) => (
            <div key={team._id} className="flex flex-col bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-gray-900 dark:text-white font-bold text-lg">{team.name}</h3>
                  {/* <p className="text-gray-500 dark:text-slate-400 text-xs">{team.members?.length || 0} Membros</p> */}
                </div>
                <button onClick={() => deleteTeam(team._id)} className="text-red-400 hover:text-red-300">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-gray-200 dark:border-slate-700">
                {team.members?.map((sub: string) => {
                  const u = users.find((x) => x.sub === sub);
                  return u ? (
                    <span key={u.sub} className="bg-slate-700 text-slate-200 px-2 py-0.5 rounded text-xs flex items-center gap-2 border border-slate-600">
                      {u.name || u.email}
                      <button onClick={() => updateTeamMembers(team._id, u.sub, 'remove')} className="text-gray-500 dark:text-slate-400 hover:text-red-400">×</button>
                    </span>
                  ) : null;
                })}
                <div className="relative group">
                  {/* <button className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 border border-slate-600 rounded px-2 py-0.5 bg-white dark:bg-slate-800">
                    <UserPlus className="w-3 h-3" /> Adicionar
                  </button> */}
                  <div className="absolute top-6 left-0 z-10 hidden group-hover:block bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded p-2 w-48 shadow-xl">
                    {users.filter((u) => !team.members.includes(u.sub)).map((u) => (
                      <button
                        key={u.sub}
                        onClick={() => updateTeamMembers(team._id, u.sub, 'add')}
                        className="block w-full text-left text-sm text-slate-300 hover:bg-slate-700 px-2 py-1 rounded"
                      >
                        {u.name || u.email}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
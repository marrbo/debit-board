// app/settings/profile/user/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import PageHeader from '@/components/PageHeader';

export default function ProfilePage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    company: '',
    jobTitle: '',
    phone: '',
  });

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) router.push('/login');

    const fetchProfile = async () => {
      setLoading(true);
      const res = await fetch('/api/user/me');
      if (res.ok) {
        const data = await res.json();
        setForm({
          name: data.name || session?.user.name || '',
          company: data.company || '',
          jobTitle: data.jobTitle || '',
          phone: data.phone || '',
        });
      } else {
        // Fallback para os dados da sessão caso a API falhe
        setForm({
          name: session?.user.name || '',
          company: '',
          jobTitle: '',
          phone: '',
        });
      }
      setLoading(false);
    };
    fetchProfile();
  }, [session, status, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const res = await fetch('/api/user/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      alert('Perfil atualizado com sucesso!');
    } else {
      const errorData = await res.json();
      alert('Erro ao salvar perfil: ' + (errorData.error || 'Erro desconhecido'));
    }
    setSaving(false);
  };

  if (loading) return <div className="text-center py-10 text-gray-500 dark:text-slate-400">Carregando perfil...</div>;

  return (
    <div className="w-full space-y-6 mx-auto">
      <PageHeader title="Profile" subtitle="Gerencie suas informações pessoais." />
      
      <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Nome Completo</label>
            <input 
              type="text" 
              value={form.name} 
              onChange={e => setForm({...form, name: e.target.value})} 
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100" 
              required 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Empresa / Organização</label>
            <input 
              type="text" 
              value={form.company} 
              onChange={e => setForm({...form, company: e.target.value})} 
              className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100" 
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Cargo</label>
              <input 
                type="text" 
                value={form.jobTitle} 
                onChange={e => setForm({...form, jobTitle: e.target.value})} 
                className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Telefone</label>
              <input 
                type="text" 
                value={form.phone} 
                onChange={e => setForm({...form, phone: e.target.value})} 
                className="w-full bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100" 
              />
            </div>
          </div>
          <button 
            type="submit" 
            disabled={saving} 
            className="bg-blue-600 hover:bg-blue-500 text-gray-900 dark:text-white px-4 py-2 rounded-lg font-medium mt-4 transition-colors disabled:opacity-50"
          >
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </button>
        </form>
      </div>
    </div>
  );
}
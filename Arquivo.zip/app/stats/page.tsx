// app/stats/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import Charts from '@/components/Charts';
import PageHeader from '@/components/PageHeader';
import AdvancedSearch from '@/components/AdvancedSearch';
import { ChartDataPoint } from '@/lib/types';

export default function StatsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('search', searchQuery);

      const res = await fetch(`/api/stats?${params.toString()}`);
      if (!res.ok) throw new Error('Erro ao carregar estatísticas');
      const data = await res.json();
      setStats(data);
    } catch (err: any) { setError(err.message); } finally { setLoading(false); }
  };

  useEffect(() => {
    if (status !== 'authenticated' || !session) return;
    fetchData();
  }, [searchQuery, session, status]);

  if (status === 'loading') return <div className="text-[#8E8E93] py-10 text-center">Carregando...</div>;
  if (!session) router.push('/login');

  if (loading) return <div className="text-center py-12"><div className="w-8 h-8 border-4 border-[#D1D1D6] dark:border-[#38383A] border-t-[#007AFF] rounded-full animate-spin mx-auto"></div></div>;
  if (error) return <div className="bg-[#FFD1D1] dark:bg-[#FF453A]/20 border border-[#FF453A]/40 rounded-xl p-6 text-[#FF453A]">{error}</div>;

  // Processamento do gráfico de linha
  const chartData: ChartDataPoint[] = (stats?.chartData || []).map((d: any) => ({
    label: format(new Date(d.label), 'dd MMM', { locale: ptBR }),
    value: d.value
  }));

  const severityTotals = stats?.severityTotals || {};
  const categoryTotals = stats?.categoryTotals || [];
  const projectTotals = stats?.projectTotals || [];

  return (
    <div className="w-full space-y-6 p-8">
      <PageHeader
        title="Stats & Usage"
        subtitle="Visão geral das issues de segurança do seu Tenant."
        searchBar={
          <AdvancedSearch onSearch={setSearchQuery} placeholder="Search stats, e.g. severity:critical OR project:my-api" />
        }
      />

      {/* 🍎 KPIs Gerais (Estilo Apple) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <p className="text-[10px] uppercase font-semibold text-[#8E8E93] tracking-wider">Total Issues</p>
          <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{stats.kpi.total}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <p className="text-[10px] uppercase font-semibold text-[#007AFF] tracking-wider">Em andamento</p>
          <p className="text-2xl font-bold text-[#007AFF] mt-1">{stats.kpi.accepted}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <p className="text-[10px] uppercase font-semibold text-[#34C759] tracking-wider">Corrigidas</p>
          <p className="text-2xl font-bold text-[#34C759] mt-1">{stats.kpi.fixed}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <p className="text-[10px] uppercase font-semibold text-[#FF9500] tracking-wider">Recorrentes</p>
          <p className="text-2xl font-bold text-[#FF9500] mt-1">{stats.kpi.recurring}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <p className="text-[10px] uppercase font-semibold text-[#8E8E93] tracking-wider">Não Corrigir</p>
          <p className="text-2xl font-bold text-[#8E8E93] mt-1">{stats.kpi.wontFix}</p>
        </div>
      </div>

      {/* 🍎 Cards de Severidade (Bordas Coloridas Esquerdas - Legível em ambos os temas) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none border-l-4 border-[#FF3B30] transition-colors">
          <p className="text-[10px] uppercase font-bold text-[#FF3B30]">Crítico</p>
          <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{severityTotals.critical || 0}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none border-l-4 border-[#FF9500] transition-colors">
          <p className="text-[10px] uppercase font-bold text-[#FF9500]">Alto</p>
          <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{severityTotals.high || 0}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none border-l-4 border-[#FFCC00] transition-colors">
          <p className="text-[10px] uppercase font-bold text-[#FFCC00]">Médio</p>
          <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{severityTotals.medium || 0}</p>
        </div>
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none border-l-4 border-[#007AFF] transition-colors">
          <p className="text-[10px] uppercase font-bold text-[#007AFF]">Baixo</p>
          <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{severityTotals.low || 0}</p>
        </div>
      </div>

      {/* 🍎 Grid de Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-5 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <h3 className="text-sm font-semibold text-[#3A3A3C] dark:text-[#98989D] mb-3">Evolução de Ocorrências</h3>
          <div className="h-64"><Charts data={chartData} type="line" /></div>
        </div>

        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-5 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <h3 className="text-sm font-semibold text-[#3A3A3C] dark:text-[#98989D] mb-3">Distribuição por Categoria</h3>
          <div className="h-64">
            {categoryTotals.length > 0 ? (
              <Charts data={categoryTotals} type="pie" />
            ) : (
              <div className="flex items-center justify-center h-full text-[#8E8E93] text-sm">
                Nenhuma categoria encontrada.
              </div>
            )}
          </div>
        </div>

        <div className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-5 shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors">
          <h3 className="text-sm font-semibold text-[#3A3A3C] dark:text-[#98989D] mb-3">Total por Projeto (TOP 10)</h3>
          <div className="h-64">
            {projectTotals.length > 0 ? (
              <Charts data={projectTotals} type="bar" />
            ) : (
              <div className="flex items-center justify-center h-full text-[#8E8E93] text-sm">
                Nenhum projeto encontrado.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
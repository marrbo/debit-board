// components/PageHeader.tsx
'use client';

import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  filters?: React.ReactNode;
  actions?: React.ReactNode;
  searchBar?: React.ReactNode;
}

export default function PageHeader({ 
  title, 
  subtitle, 
  actions, 
  searchBar 
}: PageHeaderProps) {
  return (
    <>
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#D1D1D6] dark:border-[#38383A] pb-4 mb-4 transition-colors">
        <div>
          <h1 className="text-xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7]">{title}</h1>
          {subtitle && <p className="text-sm text-[#8E8E93] dark:text-[#8E8E93] mt-1">{subtitle}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {actions}
        </div>
      </div>

      {searchBar && (
        <div className="mb-6">
          {searchBar}
        </div>
      )}
    </>
  );
}
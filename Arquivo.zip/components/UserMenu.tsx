// components/UserMenu.tsx
'use client';

import { useState } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { User, LogOut, Settings, UserMinus } from 'lucide-react';
import Link from 'next/link';

export default function UserMenu() {
  const { data: session } = useSession();
  const [isOpen, setIsOpen] = useState(false);
  const isImpersonating = session?.user?.impersonating === true;

  const handleUnimpersonate = async () => {
    const res = await fetch('/api/admin/unimpersonate', { method: 'POST' });
    if (res.ok) {
      window.location.reload(); 
    } else {
      alert('Erro ao sair da impersonação.');
    }
    setIsOpen(false);
  };

  if (!session) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 rounded-xl p-1 pr-3 transition-colors border ${isImpersonating ? 'bg-[#AF52DE]/20 border-[#AF52DE]' : 'bg-[#F2F2F7] dark:bg-[#2C2C2E] border-[#D1D1D6] dark:border-[#38383A] hover:bg-[#E5E5EA] dark:hover:bg-[#3A3A3C]'}`}
      >
        <div className="w-8 h-8 rounded-full bg-[#007AFF] flex items-center justify-center text-white font-bold text-sm">
          {session.user?.name?.charAt(0).toUpperCase() || 'U'}
        </div>
        <span className="text-sm text-[#1C1C1E] dark:text-[#F5F5F7] hidden md:block max-w-[100px] truncate">
          {session.user?.name || 'Usuário'}
        </span>
      </button>

      {isOpen && (
        <div className="absolute right-0 top-12 w-64 bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl shadow-[0_8px_24px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_24px_rgba(0,0,0,0.4)] overflow-hidden z-50 py-1 transition-colors">
          <div className="px-4 py-3 border-b border-[#D1D1D6] dark:border-[#38383A]">
            <p className="text-sm font-medium text-[#1C1C1E] dark:text-[#F5F5F7]">{session.user?.name}</p>
            <p className="text-xs text-[#8E8E93] truncate">{session.user?.email}</p>
            {isImpersonating && (
              <div className="mt-2 inline-block bg-[#AF52DE]/20 text-[#AF52DE] border border-[#AF52DE]/40 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
                🔀 Impersonando
              </div>
            )}
          </div>
          
          {isImpersonating ? (
            <button
              onClick={handleUnimpersonate}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[#FF3B30] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] hover:text-[#FF453A] transition-colors text-left border-t border-[#D1D1D6] dark:border-[#38383A] mt-1"
            >
              <UserMinus className="w-4 h-4" /> Sair da Impersonação
            </button>
          ) : (
            <>
              <Link 
                href="/settings" 
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#3A3A3C] dark:text-[#98989D] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] hover:text-[#1C1C1E] dark:hover:text-[#F5F5F7] transition-colors"
                onClick={() => setIsOpen(false)}
              >
                <Settings className="w-4 h-4" /> Configurações
              </Link>

              <button
                onClick={() => {
                  setIsOpen(false);
                  signOut({ callbackUrl: '/login' });
                }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[#FF3B30] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] hover:text-[#FF453A] transition-colors text-left border-t border-[#D1D1D6] dark:border-[#38383A] mt-1"
              >
                <LogOut className="w-4 h-4" /> Sair
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
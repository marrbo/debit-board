// components/KPICards.tsx
'use client';

import { SearchItem } from '@/lib/types';
import { FileCode, FolderTree, GitBranch, Target } from 'lucide-react';

interface KPICardsProps {
  items: SearchItem[];
}

export default function KPICards({ items }: KPICardsProps) {
  const totalFiles = items.length;
  const uniqueProjects = new Set(items.map((i) => i.project)).size;
  const uniqueRepos = new Set(items.map((i) => i.repository)).size;
  const totalHits = items.reduce((sum, item) => sum + (item.hitCount || 0), 0);

  const cards = [
    {
      label: 'Total de Arquivos',
      value: totalFiles,
      icon: FileCode,
      color: 'text-[#007AFF]',
      bg: 'bg-[#007AFF]/10',
    },
    {
      label: 'Projetos',
      value: uniqueProjects,
      icon: FolderTree,
      color: 'text-[#34C759]',
      bg: 'bg-[#34C759]/10',
    },
    {
      label: 'Repositórios',
      value: uniqueRepos,
      icon: GitBranch,
      color: 'text-[#AF52DE]',
      bg: 'bg-[#AF52DE]/10',
    },
    {
      label: 'Total Hits',
      value: totalHits,
      icon: Target,
      color: 'text-[#FF9500]',
      bg: 'bg-[#FF9500]/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {cards.map((card) => (
        <div
          key={card.label}
          className="bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl p-4 flex items-center justify-between shadow-[0_2px_8px_rgba(0,0,0,0.02)] dark:shadow-none transition-colors"
        >
          <div>
            <p className="text-[10px] uppercase font-semibold text-[#8E8E93] dark:text-[#636366] tracking-wider">
              {card.label}
            </p>
            <p className="text-2xl font-bold text-[#1C1C1E] dark:text-[#F5F5F7] mt-1">{card.value}</p>
          </div>
          <div className={`p-3 rounded-xl ${card.bg}`}>
            <card.icon className={`w-6 h-6 ${card.color}`} />
          </div>
        </div>
      ))}
    </div>
  );
}
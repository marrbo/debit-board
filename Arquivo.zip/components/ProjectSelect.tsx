// components/ProjectSelect.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, Check, FolderGit2 } from 'lucide-react';

interface ProjectSelectProps {
  projects: { _id: string; name: string }[];
  selectedId: string;
  onChange: (id: string) => void;
  placeholder?: string;
}

export default function ProjectSelect({ projects, selectedId, onChange, placeholder = 'All Projects (Global)' }: ProjectSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredProjects = projects.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedLabel = selectedId === 'all' 
    ? placeholder 
    : projects.find(p => p._id === selectedId)?.name || placeholder;

  return (
    <div className="relative w-full md:w-64" ref={wrapperRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between gap-2 bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl px-3 py-1.5 text-sm text-[#1C1C1E] dark:text-[#F5F5F7] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] transition-colors focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 shadow-sm"
      >
        <span className="truncate">{selectedLabel}</span>
        <ChevronDown className={`w-4 h-4 text-[#8E8E93] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute left-0 top-full mt-2 w-full min-w-[240px] bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-2xl shadow-[0_8px_24px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_24px_rgba(0,0,0,0.4)] z-50 p-2 overflow-hidden">
          
          <div className="relative mb-2 border-b border-[#D1D1D6] dark:border-[#38383A] pb-2">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-[#8E8E93]" />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#FFFFFF] dark:bg-[#1C1C1E] border border-[#D1D1D6] dark:border-[#38383A] rounded-xl pl-8 pr-3 py-1.5 text-xs text-[#1C1C1E] dark:text-[#F5F5F7] focus:outline-none focus:ring-1 focus:ring-[#007AFF]"
            />
          </div>

          <div className="space-y-0.5 max-h-60 overflow-y-auto pr-1">
            <button
              onClick={() => { onChange('all'); setIsOpen(false); }}
              className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-xl text-xs text-left transition-colors ${selectedId === 'all' ? 'bg-[#007AFF]/10 text-[#007AFF]' : 'text-[#3A3A3C] dark:text-[#98989D] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E]'}`}
            >
              <FolderGit2 className="w-3.5 h-3.5 shrink-0 text-[#8E8E93]" />
              <span>All Projects (Global)</span>
              {selectedId === 'all' && <Check className="w-3.5 h-3.5 ml-auto text-[#007AFF]" />}
            </button>

            {filteredProjects.length === 0 && searchTerm && (
              <div className="px-2 py-2 text-xs text-[#8E8E93] text-center">Nenhum projeto encontrado.</div>
            )}

            {filteredProjects.map((p) => (
              <button
                key={p._id}
                onClick={() => { onChange(p._id); setIsOpen(false); }}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-xl text-xs text-left transition-colors ${selectedId === p._id ? 'bg-[#007AFF]/10 text-[#007AFF]' : 'text-[#3A3A3C] dark:text-[#98989D] hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E]'}`}
              >
                <div className="w-5 h-5 rounded bg-[#F2F2F7] dark:bg-[#38383A] flex items-center justify-center text-[8px] text-[#1C1C1E] dark:text-[#F5F5F7] font-bold shrink-0">
                  {p.name.charAt(0).toUpperCase()}
                </div>
                <span className="truncate">{p.name}</span>
                {selectedId === p._id && <Check className="w-3.5 h-3.5 ml-auto text-[#007AFF]" />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}